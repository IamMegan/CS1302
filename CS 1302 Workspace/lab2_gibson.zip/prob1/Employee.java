package prob1;

public class Employee {
	
	private String name;

	public static void main(String[] args) {
		
		System.out.println("Hello World");

	}

}
